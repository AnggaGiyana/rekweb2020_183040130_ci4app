<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>About Me</h1>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Id, vel eligendi. Dolorum quasi qui rem tenetur reiciendis amet repudiandae vero deserunt explicabo neque unde nisi, porro suscipit quisquam quis officiis!</p>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>